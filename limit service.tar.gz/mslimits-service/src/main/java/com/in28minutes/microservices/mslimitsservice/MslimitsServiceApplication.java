package com.in28minutes.microservices.mslimitsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MslimitsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MslimitsServiceApplication.class, args);
	}
}
